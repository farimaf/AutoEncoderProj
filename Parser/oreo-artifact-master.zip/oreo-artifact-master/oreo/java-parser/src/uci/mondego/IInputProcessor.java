package uci.mondego;

import java.io.FileNotFoundException;

public interface IInputProcessor {
    public void processInput(String filename) throws FileNotFoundException;

}
