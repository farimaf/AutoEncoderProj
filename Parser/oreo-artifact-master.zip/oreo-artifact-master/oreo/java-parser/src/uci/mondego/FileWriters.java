package uci.mondego;

import java.io.Writer;

public class FileWriters {
    public static Writer metricsFileWriter = null;
    public static Writer bookkeepingWriter = null;
    public static Writer tokensFileWriter = null;
    public static Writer errorPw = null;
    
}
