package com.mondego.models;

public class TermInfo {
    public int position;
    public int frequency;
}
